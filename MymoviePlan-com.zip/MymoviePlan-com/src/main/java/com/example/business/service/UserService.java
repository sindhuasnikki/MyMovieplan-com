package com.example.business.service;

import com.example.data.entity.User;

public interface UserService {
    void save(User user);

    User findByUsername(String username);
}
