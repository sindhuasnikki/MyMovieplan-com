package com.example;

import com.example.business.service.ScreeningServiceIntegrationTest;
import com.example.data.repository.ScreeningRepositoryIntegrationTest;
import com.example.web.application.ScreeningControllerIntegrationTest;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({ScreeningServiceIntegrationTest.class, ScreeningControllerIntegrationTest.class,
        ScreeningRepositoryIntegrationTest.class})
public class MovieScreeningTestSuite {
}
